#!/bin/sh
w=.superpowers/sdd/2026-10-19-colt-cancellation-centralization
PATH="/opt/homebrew/opt/llvm@23/bin:$PATH" bazel run //:clang_tidy_report_changed > "$w/delivery-tidy.log" 2>&1
code=$?
printf 'clang-tidy: %s\n' "$code"
printf '%s\n' "$code" > "$w/delivery-tidy.exit"
COVERAGE_DIR="$PWD/$w/coverage" scripts/coverage-local.sh > "$w/delivery-coverage.log" 2>&1
code=$?
printf 'coverage: %s\n' "$code"
printf '%s\n' "$code" > "$w/delivery-coverage.exit"
PATH="/opt/homebrew/opt/llvm@22/bin:$PATH" python3 scripts/mutation_test.py --diff-ref 883b2afb89464e576ab9a07cdd3442dc997e2130 --report-dir "$w/mull-reports" > "$w/delivery-mutation.log" 2>&1
code=$?
printf 'mutation: %s\n' "$code"
printf '%s\n' "$code" > "$w/delivery-mutation.exit"
