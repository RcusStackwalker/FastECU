### Task 1: Implement the guarded CAN port and prove its contract

**Files:** Create the three `guarded_can_flash_transport*` C++ files and results record above; regenerate `src/backend/flash/BUILD.bazel`.

**Interfaces:** Consumes ICanFlashTransport, ICancellationToken, Status and Result from existing contracts. Produces `fastecu::flash::GuardedCanFlashTransport final : public ICanFlashTransport`, with this public API:

```cpp
explicit GuardedCanFlashTransport(ICanFlashTransport& inner) noexcept;
Status ResetConnection() override;
Status Configure(const Iso15765Config& config) override;
Status Open() override;
Status Close() override;
Status RestartIso15765(const Iso15765Config& config, const ICancellationToken& cancellation) override;
void RequestUnblock() noexcept override;
Status Write(bytes::ByteView data, const ICancellationToken& cancellation) override;
Result<std::optional<bytes::Bytes>> Read(std::chrono::milliseconds timeout,
                                      const ICancellationToken& cancellation) override;
```

- [ ] **Step 1: Freeze the comparison before any C++ edits.** At execution time use the worktree skill to establish an isolated feature branch; preserve unrelated files. Pin `PILOT_BASE_SHA` to its initial HEAD and record source drift from spec baseline `2b9613b8275a35fa485caa757a05ba628f163744`. Create a task-specific temporary evidence directory and the results record. Record toolchain/Qt, CPU/OS, scheduling, source hashes, named baseline cases, and the four check sites. Do not use either old PR as the baseline.

  Freeze this ordinary-runtime manifest as `PILOT_TESTS` in the execution shell and preserve it in the results record:

```sh
PILOT_TESTS=(
  //src/backend/flash:flash_executor_test
  //src/backend/flash:bound_flash_attempt_test
  //src/backend/flash:can_flash_uds_channel_test
  //src/backend/flash/ecu:mitsu_colt_m32r_can_plan_test
  //src/backend/flash/ecu:mitsu_colt_m32r_can_executor_test
  //src/backend/flash/ecu:uds_client_exchange_common_test
  //src/backend/flash/testing:scripted_flash_transports_test
  //src/backend/protocol/uds:uds_client_test
  //src/backend/ports/testing:fake_clock_test
)
bazel test --config=release --nocache_test_results --local_test_jobs=1 "${PILOT_TESTS[@]}"
python3 scripts/nloc_loop.py measure --json
prek run nloc --hook-stage manual --all-files
```

  Require all tests to pass. Run one warm-up followed by five measured invocations of the test command; after each, preserve each target's XML from `bazel info bazel-testlogs` before the next invocation overwrites it. Save both NLOC outputs. For each target XML, use the root `time` attribute once when present, otherwise sum its direct testsuite children's `time` attributes; never also sum nested testcase times; store all five sums and their median. Exclude build/wall time and competing builds. Resolve a failing baseline before comparing candidates.

- [ ] **Step 2: Declare the guard API in its header.** Store only `ICanFlashTransport& inner_`. Include existing flash_executor contracts; do not add a token member, lifecycle owner, or reciprocal include. Leave method definitions for the green step.
- [ ] **Step 3: Write the contract tests.** Define a test-local `ProbeCanTransport` derived from existing ScriptedCanFlashTransport. Its overridden Read/Write deliberately ignore token state, record bytes/timeout/token identity and call counts, optionally cancel a supplied ManualCancellationToken inside the call, and return a configured result. Override RestartIso15765 to record config/token and return a distinctive configured result without invoking the port default. Count RequestUnblock; reuse inherited lifecycle counters/results. Do not copy payloads beyond this tiny unit fixture or add common fake APIs.

  Use suite name `GuardedCanFlashTransport`. Write these named tests; rows describe concrete arrangements and assertion expressions. Each row gets fresh transport/token/guard state; parameterized rows use named GoogleTest parameters.

| Test | Arrangement and assertions |
| --- | --- |
| `PrecancelledWriteDoesNotDelegate`, `PrecancelledReadDoesNotDelegate` | Cancel first; `ASSERT_THAT(guard.Write(data, token), IsErrWith(ErrorKind::kCancelled, "CAN write cancelled before delegation"))` or corresponding Read/read text; `EXPECT_EQ(inner.write_calls, 0)` / `EXPECT_EQ(inner.read_calls, 0)`. |
| `ForwardsBytesTimeoutAndOriginalToken` | Write `{0x00,0x80,0xFF}`, Read at `37ms`; `ASSERT_THAT(sent, IsOk())`; `EXPECT_THAT(inner.last_write, ElementsAre(0x00,0x80,0xFF))`; `EXPECT_EQ(inner.last_timeout, 37ms)`; both recorded token addresses equal `&token`; one call each. |
| `ReadOutcomesPassThrough` | Cases absent optional, present-empty Bytes, and `{0x12,0xA5}`; `ASSERT_THAT(actual, IsOk())`; `EXPECT_EQ(*actual, expected_optional)` with exact engagement and contents. Repeat with cancellation triggered inside Read; `EXPECT_TRUE(token.Cancelled())` and the same outcome assertions. |
| `TypedFailuresPassThrough` | Read and Write, each ErrorKind (`kInvalidConfig`, `kTimeout`, `kDisconnected`, `kBadResponse`, `kCancelled`, `kUnsupported`, `kInternal`), detail `"delegate detail"`, with/without inside-call cancellation: `ASSERT_THAT(actual, IsErrWith(kind, "delegate detail"))`; exactly one delegate call. |
| `AcceptedWriteSuccessSurvivesInsideCallCancellation` | Inner Write cancels then returns success; `ASSERT_THAT(actual, IsOk())`; `EXPECT_TRUE(token.Cancelled())`; `EXPECT_EQ(inner.write_calls, 1)`. |
| `FailureDoesNotPoisonTheNextCall` | Live token: inner Write returns kDisconnected, then succeeds; `ASSERT_THAT(first, IsErr(ErrorKind::kDisconnected))`; `ASSERT_THAT(second, IsOk())`; `EXPECT_EQ(inner.write_calls, 2)`. |
| `LifecycleRestartAndUnblockForwardAfterCancellation` | Cancel first; config `{500000,0x7E0,0x7E8,false}`. Reset/configure/open/close counters each one and lifecycle order matches calls; all four config fields preserved. Restart returns configured `kUnsupported/"restart override"`, restart count one, same config/token, and no extra reset/configure/open; unblock count one. Parameterize lifecycle failure returns to assert unchanged kind/detail as well. |

- [ ] **Step 4: Generate the targets and run red.** `python3 scripts/gazelle_check.py --fix`, then `bazel test --config=release //src/backend/flash:guarded_can_flash_transport_test`. Expect unresolved guard definitions, not a missing dependency or toolchain failure. Review generated targets; do not hand-edit managed BUILD files.
- [ ] **Step 5: Implement the declared methods in the .cpp.** Read/Write return the exact cancellation details above only when the supplied token is observed cancelled at entry; otherwise return the inner call's result directly. Forward every other operation directly, including the inner restart override and noexcept unblock. Generate BUILD updates again.
- [ ] **Step 6: Run green.** Run `bazel test --config=release //src/backend/flash:guarded_can_flash_transport_test //src/backend/flash/testing:scripted_flash_transports_test`; expect PASS. Recheck formatting and generated dependencies: guard → flash_executor only, no family dependency. Do not expand the runtime manifest to hide self-test cost.
- [ ] **Step 7: Commit the independently tested decorator.** Stage only the three new C++ files, generated flash BUILD, and the results record; commit `feat: add cancellation-only CAN transport guard`.

