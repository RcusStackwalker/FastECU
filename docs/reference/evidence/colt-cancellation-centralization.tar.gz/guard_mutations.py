from pathlib import Path
import hashlib,json,subprocess
w=Path(__file__).parent
p=Path('src/backend/flash/guarded_can_flash_transport.cpp')
original=p.read_text()
mutations=[]
for operation in ('Write','Read'):
 pos=original.index('GuardedCanFlashTransport::'+operation+'(')
 tail=original[pos:]
 bypass=original[:pos]+tail.replace('if (cancellation.Cancelled())','if (false && cancellation.Cancelled())',1)
 mutations.append((operation.lower()+'-entry-bypass',bypass,'Precancelled'+operation+'DoesNotDelegate'))
 call='inner_.Write(data, cancellation)' if operation=='Write' else 'inner_.Read(timeout, cancellation)'
 late=original.replace('return '+call+';',f'''auto result = {call};
    if (cancellation.Cancelled())
    {{
        return Fail(ErrorKind::kCancelled, "mutant post-call cancellation");
    }}
    return result;''',1)
 mutations.append((operation.lower()+'-post-call-check',late,'AcceptedWriteSuccessSurvivesInsideCallCancellation' if operation=='Write' else 'ReadOutcomesPassThrough'))
records=[]
for name,mutant,expected in mutations:
 assert original!=mutant
 try:
  p.write_text(mutant)
  command=['bazel','test','--config=release','//src/backend/flash:guarded_can_flash_transport_test']
  with (w/(name+'.log')).open('w') as log:
   result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  output=(w/(name+'.log')).read_text()
  assert result.returncode==3 and expected in output, output[-5000:]
  records.append({'name':name,'path':str(p),'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'command':command,'exit':result.returncode,'expected_failed_test':expected})
  print(name,'rejected by',expected,flush=True)
 finally:
  p.write_text(original)
(w/'guard-mutations.json').write_text(json.dumps(records,indent=2)+'\n')
