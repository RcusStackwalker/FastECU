from pathlib import Path
import hashlib,json,subprocess,tarfile
w=Path(__file__).parent
base='883b2afb89464e576ab9a07cdd3442dc997e2130'
for kind,path in [('plan','docs/superpowers/plans/2026-10-19-colt-cancellation-centralization.md'),('spec','docs/superpowers/specs/2026-10-19-guarded-transport-refinement-design.md')]:
 (w/('original-'+kind+'.md')).write_bytes(subprocess.check_output(['git','show',base+':'+path]))
files=[]
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.name=='SHA256SUMS' or p.name.endswith(('.profraw','.profdata')): continue
 if 'profiles' in p.relative_to(w).parts or '__pycache__' in p.parts: continue
 files.append(p)
(w/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(w).as_posix()+'\n' for p in files))
archive=Path('docs/reference/evidence/colt-cancellation-centralization.tar.gz')
archive.parent.mkdir(parents=True,exist_ok=True)
with tarfile.open(archive,'w:gz') as tar:
 for p in files+[w/'SHA256SUMS']: tar.add(p,arcname=p.relative_to(w),recursive=False)
print(str(archive),archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest())
