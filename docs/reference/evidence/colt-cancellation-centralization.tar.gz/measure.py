import pathlib, re, shutil, statistics, subprocess, sys, xml.etree.ElementTree as ET, json
w=pathlib.Path(__file__).parent
side=sys.argv[1]
targets=re.findall(r'^  (//\S+)',(w/'manifest.sh').read_text(),re.M)
if side=='candidate': targets+=['//src/backend/flash:guarded_can_flash_transport_test']
sums=[]
for i in range(1,6):
    with (w/f'{side}-{i}.log').open('w') as log:
        subprocess.run(['bazel','test','--config=release','--nocache_test_results','--local_test_jobs=1',*targets],stdout=log,stderr=subprocess.STDOUT,check=True)
    total=0
    for target in targets:
        relative=target[2:].replace(':','/')
        src=pathlib.Path('bazel-testlogs')/relative/'test.xml'
        dest=w/f'{side}-{i}'/relative/'test.xml'
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dest)
        root=ET.parse(dest).getroot()
        total+=float(root.attrib['time']) if 'time' in root.attrib else sum(float(s.attrib.get('time','0')) for s in root.findall('testsuite'))
    sums.append(total)
result={'targets':targets,'sums':sums,'median':statistics.median(sums)}
(w/f'{side}-runtime.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
