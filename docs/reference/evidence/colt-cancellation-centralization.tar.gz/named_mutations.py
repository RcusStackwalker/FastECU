from pathlib import Path
import hashlib,json,subprocess
w=Path(__file__).parent
runner=Path('src/backend/flash/flash_executor.h')
colt=Path('src/backend/flash/ecu/mitsu_colt_m32r_can_executor.cpp')
source=colt.read_text()
unlock_start=source.index('Status UnlockAndErase(')
return_pos=source.index('return std::unexpected(received.error());',unlock_start)
erase='''    if (const Status erased = UnlockAndErase(ctx, ""); !erased.has_value())
    {
        return erased;
    }'''
mutations=[
 ('runner-bypass',runner,runner.read_text().replace('return executor_->Execute(plan_, guard, clock, cancellation, events);','return executor_->Execute(plan_, *transport_, clock, cancellation, events);',1),'MitsuColtM32rCanExecutor.ColtBoundAttemptStopsBeforeReadWhenCancelledAfterWrite'),
 ('unlock-abort',colt,source[:return_pos]+source[return_pos:].replace('return std::unexpected(received.error());','/* mutation: continue after unlock failure */',1),'MitsuColtM32rCanWriteExecutor.WriteStopsWhenTheReflashUnlockIsRejected'),
 ('erase-abort',colt,source.replace(erase,erase.replace('return erased;','/* mutation: continue after erase failure */'),1),'MitsuColtM32rCanWriteExecutor.WriteStopsWhenTheEraseTriggerIsRejected')]
records=[]
for name,path,mutant,test in mutations:
 original=path.read_text()
 assert mutant!=original
 try:
  path.write_text(mutant)
  command=['bazel','test','--config=release','//src/backend/flash/ecu:mitsu_colt_m32r_can_executor_test','--test_arg=--gtest_filter='+test]
  with (w/(name+'.log')).open('w') as log:
   result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  output=(w/(name+'.log')).read_text()
  assert result.returncode==3 and 'Which is: 1' in output, output[-5000:]
  assert ('inner.read_attempts' if name=='runner-bypass' else 'WatchedWriteAttempts()') in output
  records.append({'name':name,'path':str(path),'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'mutant_sha256':hashlib.sha256(mutant.encode()).hexdigest(),'command':command,'exit':result.returncode,'assertion':'Read attempts 1 vs 0' if name=='runner-bypass' else 'Forbidden request attempts 1 vs 0'})
  print(name, 'killed by attempted-operation assertion',flush=True)
 finally:
  path.write_text(original)
(w/'named-mutations.json').write_text(json.dumps(records,indent=2)+'\n')
