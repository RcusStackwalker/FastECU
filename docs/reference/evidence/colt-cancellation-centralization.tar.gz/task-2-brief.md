### Task 2: Install compatible opt-in guards at the runner boundary

**Files:** Modify `src/backend/flash/flash_executor.h`, `src/backend/flash/bound_flash_attempt_test.cpp`; regenerate `src/backend/flash/BUILD.bazel`.

**Interfaces:** Consumes Task 1's constructor and port implementation. Produces support in existing `BoundAttempt<Executor, Transport>::Run(IClock&, const ICancellationToken&, IEventSink&) -> Result<FlashExecutionResult>` for `typename Executor::CancellationGuard`, constructible from the owned transport and derived from `Executor::TransportType`. No public signature changes.

- [ ] **Step 1: Write opted-in runner tests.** Add a local cancellation-blind CAN transport with write/unblock counters, and a `CanExecutorProbe : ICanFlashExecutor` that returns config `{500000,0x7E0,0x7E8,false}` and can cancel its supplied ManualCancellationToken immediately before Execute calls Write. A `GuardedCanExecutorProbe` subclass adds only `using CancellationGuard = GuardedCanFlashTransport` and inherits the constructor. Bind concrete types with existing BindFlashAttempt; keep existing K-Line/mixed suites untouched.

| New runner test | Assertions |
| --- | --- |
| `OptedInExecutorRefusesCancelledWrite` | Cancel inside Execute; `ASSERT_THAT(result, IsErr(ErrorKind::kCancelled))`; `EXPECT_EQ(inner.write_calls, 0)`; configure/open/close each one. |
| `UnoptedInCanExecutorKeepsItsExistingPath` | Same cancellation-blind probe without alias; `ASSERT_THAT(result, IsOk())`; `EXPECT_EQ(inner.write_calls, 1)`; close one. |
| `OptedInExecutionErrorWinsOverCloseError` | Execution cancellation plus close kInternal; `ASSERT_THAT(result, IsErr(ErrorKind::kCancelled))`; close one; warning retained. |
| `OptedInCloseOnlyFailureIsReturned` | Successful execution plus close `kInternal/"close failed"`; `ASSERT_THAT(result, IsErrWith(ErrorKind::kInternal, "close failed"))`; close one. |
| `OptedInUnblockReachesOwnedTransport` | Call attempt.RequestUnblock before/after Run; inner unblock count increments each time, including without a live stack guard. |

- [ ] **Step 2: Generate dependencies and run red.** `python3 scripts/gazelle_check.py --fix`; `bazel test --config=release //src/backend/flash:bound_flash_attempt_test`. The opted-in refusal test must fail with one raw write instead of zero; existing tests remain valid.
- [ ] **Step 3: Implement opt-in execution in Run.** Use dependent-type detection (`requires { typename Executor::CancellationGuard; }`) and enforce compatibility/constructibility at compile time. Construct the named guard on the stack only in that branch and pass it to Execute; otherwise pass the owned transport. Keep both branches within the execution-result computation so the existing final-close/error precedence is shared. Leave preparation, configure/open, admission polls and RequestUnblock unchanged. No concrete guard/Colt include or virtual capability is added to flash_executor.h.
- [ ] **Step 4: Run green.** Run `bazel test --config=release //src/backend/flash:bound_flash_attempt_test //src/backend/flash:flash_executor_test //src/backend/flash:guarded_can_flash_transport_test`. Expect PASS, including existing `CancellationIsNotUniversallyPolledBetweenConfigureAndOpen`, mixed lifecycle, and close precedence cases. Review generated deps and static assertions.
- [ ] **Step 5: Commit.** Stage only the runner header/test and generated flash BUILD; commit `refactor: support executor-selected cancellation guards`.

